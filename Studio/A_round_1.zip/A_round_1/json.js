var quiz = [

{
	"question" : "AF",
	"correctanswer": "AS FUCK",
	"answer2": "ADOPTIVE FATHER",
	"answer3": "AUTO FOCUS",
	"answer4": "ALWAYS FRESH",

},

{

	"question" : "BF",
	"correctanswer": "BOYFRIEND",
	"answer2": "BLACK FRIDAY",
	"answer3": "BEST FRIEND",
	"answer4": "BRAIN FREEZE",
},

{

	"question" : "DL",
	"correctanswer": "DOWN LOW",
	"answer2": "DIRECT LINK",
	"answer3": "DEMI LOVATO",
	"answer4": "DARK LORD",
},

{

	"question" : "FU",
	"correctanswer": "FUCK YOU",
	"answer2": "FLORIDA UNIVERSITY",
	"answer3": "FREAKING UGLY",
	"answer4": "FREAKY YOU",
},

{

	"question" : "TY",
	"correctanswer": "THANK YOU",
	"answer2": "TOO YOUNG",
	"answer3": "TAX YEAR",
	"answer4": "TEACH YOURSELF",
},

{

	"question" : "LN",
	"correctanswer": "LAST NIGHT",
	"answer2": "LIGHT NOVEL",
	"answer3": "LIKE NEW!",
	"answer4": "LOCAL NATION",
},

{

	"question" : "TN",
	"correctanswer": "TONIGHT",
	"answer2": "TENNESSEE",
	"answer3": "TREE NUT",
	"answer4": "TRADE NAME",
},

{

	"question" : "RN",
	"correctanswer": "RIGHT NOW",
	"answer2": "REAL NEW",
	"answer3": "ROMAN NUMERALS",
	"answer4": "RANDOM NIGHT",
},

{

	"question" : "TM",
	"correctanswer": "TOMORROW",
	"answer2": "TEXT MESSAGE",
	"answer3": "TRUST ME",
	"answer4": "TIM McGRAW",
},

]
